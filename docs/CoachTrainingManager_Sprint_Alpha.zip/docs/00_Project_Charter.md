# Coach's Training Manager

## Project Charter

### Mission
Build better players by helping coaches coach better.

### Vision
Coach's Training Manager is a player development platform designed to help coaches plan purposeful training sessions, organize coaching knowledge, preserve coaching experience, and support long-term player growth.

The software exists to support coaching. It does not replace coaching judgment.

### Guiding Philosophy
> "Progress is more important than perfection."  
> — Bob Powers

### Core Principles
1. Technology serves the coach.
2. Coaching philosophy drives the software.
3. Player development comes before administration.
4. The coach is always the decision-maker.
5. The software asks thoughtful questions instead of giving coaching answers.
6. Progress is more important than perfection.
7. Observe often. Assess periodically.
8. Knowledge grows more valuable over time.
9. Every feature should help a coach develop better players.
10. Code should be written for the programmer who follows.

### Product Pillars
- Practice Builder
- Development Library
- Player Development
- Coach's Journal
- Season Development

### Product Test
Whenever we finish a feature, we ask:

> Does this help a coach develop better players?

---

**Coach's Training Manager**  
*Build Better Players. One Practice at a Time.*
