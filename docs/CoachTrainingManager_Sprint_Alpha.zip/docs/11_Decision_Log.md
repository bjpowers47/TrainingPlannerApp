# Decision Log

## Decision 001
**Decision:** Coach's Training Manager is a player development platform, not an Excel replacement.

## Decision 002
**Decision:** SQLite will be the primary application database.

## Decision 003
**Decision:** The application uses six permanent Development Blocks inspired by Coerver-style development.

## Decision 004
**Decision:** The application will not use software-generated target ratings.

## Decision 005
**Decision:** Ratings are called Development Snapshots.

## Decision 006
**Decision:** Progress is more important than perfection.

---

**Coach's Training Manager**  
*Build Better Players. One Practice at a Time.*
