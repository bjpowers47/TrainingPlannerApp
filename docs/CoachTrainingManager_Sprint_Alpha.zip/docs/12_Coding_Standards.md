# Coding Standards

## Engineering Philosophy
Code should be written for the programmer who follows.

## Principles
1. Readability beats cleverness.
2. Explicit beats implicit.
3. Business logic should read like the coaching domain.
4. Avoid hidden magic.
5. Keep methods short.
6. Keep classes focused.
7. Comments should explain why.
8. Prefer maintainability over compactness.
9. Simple code scales better than clever code.

---

**Coach's Training Manager**  
*Build Better Players. One Practice at a Time.*
