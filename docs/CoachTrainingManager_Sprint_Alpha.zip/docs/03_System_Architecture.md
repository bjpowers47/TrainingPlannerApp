# System Architecture

## Design Goal
The system should be easy to understand, easy to maintain, and organized around coaching concepts.

## Architecture Layers
```text
User Interface
    ↓
Controllers
    ↓
Services
    ↓
Repositories
    ↓
SQLite Database
```

## Engineering Principle
Simple code scales better than clever code.

## Responsibilities
- UI displays screens and collects input.
- Controllers coordinate user actions.
- Services contain business logic.
- Repositories handle database access.
- Models represent real coaching concepts.

---

**Coach's Training Manager**  
*Build Better Players. One Practice at a Time.*
