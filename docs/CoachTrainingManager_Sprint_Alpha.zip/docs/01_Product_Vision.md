# Product Vision

Coach's Training Manager is not an Excel replacement. It is a coaching platform.

The application helps coaches organize ideas, build purposeful practices, track player progress, reflect on sessions, and preserve coaching knowledge across seasons.

## What Makes It Different

Most sports software begins with administration. Coach's Training Manager begins with player development.

## Core Workflow
1. Select a team.
2. Review recent development observations.
3. Define today's training objective.
4. Build a practice using Development Blocks.
5. Run the session.
6. Record reflections and observations.
7. Use those reflections to plan future sessions.

---

**Coach's Training Manager**  
*Build Better Players. One Practice at a Time.*
