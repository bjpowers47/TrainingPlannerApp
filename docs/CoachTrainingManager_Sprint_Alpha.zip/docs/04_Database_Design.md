# Database Design

## Database
```text
data/coach_training.db
```

## First Core Tables
- development_blocks
- technical_focuses
- drills
- teams
- players
- development_snapshots
- observations
- practice_sessions
- practice_blocks

## Key Decisions
- Excel is import/export only.
- SQLite is the primary database.
- Development Snapshots track progress over time.
- The system does not use software-generated target ratings.
- Data should be archived rather than deleted when practical.

---

**Coach's Training Manager**  
*Build Better Players. One Practice at a Time.*
