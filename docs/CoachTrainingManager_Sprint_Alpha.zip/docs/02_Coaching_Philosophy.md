# Coaching Philosophy

Coach's Training Manager is built around a player-development philosophy influenced by Coerver-style technical development.

The application is not affiliated with, endorsed by, or an official product of Coerver Coaching. It is inspired by structured technical development principles while leaving each coach in control.

## Guiding Principle
> Progress is more important than perfection.

## Six Development Blocks
1. Ball Mastery
2. Receiving & Passing
3. 1v1 Moves
4. Speed & Agility
5. Finishing
6. Group Play

## Development Snapshots
A Development Snapshot is a periodic coach assessment of a player or team across the six Development Blocks.

A snapshot is not a label. It captures a moment in time.

## Observations
Observations are frequent coaching notes that provide context for later reflection and assessment.

---

**Coach's Training Manager**  
*Build Better Players. One Practice at a Time.*
