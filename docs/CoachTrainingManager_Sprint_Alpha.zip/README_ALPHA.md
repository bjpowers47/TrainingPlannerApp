# Coach's Training Manager — Sprint Alpha Package

## Apply These Files

Copy these folders/files into your project root:

- `docs/`
- `app/database.py`
- `app/models/development_block.py`
- `app/repositories/development_block_repository.py`
- `scripts_initialize_database.py`

## Run

```cmd
python scripts_initialize_database.py
```

Expected output:

```text
Database initialized.

Development Blocks
------------------
1. Ball Mastery
2. Receiving & Passing
3. 1v1 Moves
4. Speed & Agility
5. Finishing
6. Group Play
```

## Commit

```cmd
git add .
git commit -m "Alpha: Add project blueprint and SQLite foundation"
```
